from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static 

urlpatterns = [
    path('', views.index, name = "index"),
    path('pasxalka/', views.pasxalka, name = "pasxalka"),
    path('profile/', views.profile, name = "profile"),
    path("login/", views.login_request, name="login"),
    path('accounts/login/', auth_views.LoginView.as_view()),
    path('register/', views.register, name="register"),
    path("logout/", views.logoutMe, name="logoutMe"),




    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)