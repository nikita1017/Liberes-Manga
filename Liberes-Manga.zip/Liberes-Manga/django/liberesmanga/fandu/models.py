from math import degrees
from xml.etree.ElementInclude import default_loader
from django.db import models

# Create your models here.
class Post(models.Model):
    picture = models.ImageField(upload_to = "images/")
    name = models.CharField(max_length = 150, default = "")
    yeare = models.CharField(max_length=50, default="")
    author = models.CharField(max_length=50, default= "")
    opisanie = models.TextField(default = "")
    
    